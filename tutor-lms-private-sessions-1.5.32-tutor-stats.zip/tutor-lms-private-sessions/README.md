# Tutor LMS Private Sessions 1.5.32

Standalone 1-to-1 private tutoring requests for Tutor LMS Native eCommerce.

### Workflow
1. Student opens a tutor's private booking page and sends a request.
2. Request appears in the student's Tutor LMS dashboard under **Private Sessions**.
3. Tutor approves or rejects the request from the instructor dashboard. Approval never opens checkout for the tutor.
4. If admin approval is enabled, the request goes to **Pending admin approval**. Admin can approve/reject it from **Tutor LMS > Private Sessions**.
5. Once approved, the student sees **Proceed to payment** in their own dashboard and completes payment using Tutor LMS Native eCommerce.
6. After payment/confirmation, the tutor can enter an online meeting URL and/or offline meeting instructions. The student sees those details in the student dashboard; an email notification is sent when the tutor saves details.

### Dashboard
- Instructors: Tutor dashboard → Private Sessions.
- Students: Tutor dashboard → Private Sessions.
- The student menu item is not shown to instructor accounts.

No WooCommerce dependency.

Version 1.2.2: two-column instructor settings/requests UI; free tryout approval confirms immediately; booking form uses Subject, Goal and Additional information.


Version 1.3.0: the public-profile **Book Private Session** action opens an in-page modal; booking price updates live after subject/duration selection; tutors can select Tutor LMS course categories they teach, set a 1-hour price for each, and define duration multipliers (defaults: 30m 0.5×, 45m 0.75×, 1h 1×, 1.5h 1.4×, 2h 1.7×). Student and instructor dashboards received refreshed summary cards and spacing.


Version 1.4.0: redesigned private tutoring workflow. Students submit a request with their contact information, subject, learning goal, requested hours, preferred time, and learning method (online / at tutor home / at student home). Tutors respond with a proposed date/time, duration, price and message. Students can accept the proposal and add it to Tutor LMS Native eCommerce checkout, or decline it and submit a fresh request with the previous information prefilled. After payment, tutors can send the final meeting link or offline location/details.

Version 1.5.3: generated private-session checkout courses now receive a built-in default thumbnail when no featured image exists.


## 1.5.5
- Removed the phone helper message from the student request form.
- Added a separate **My Private Sessions** Tutor LMS dashboard item for instructors who also act as learners.
- The learner page uses the Tutor LMS dashboard icon and shows the instructor's own student requests without replacing the tutor management page.


## 1.5.12
- Private-session Tutor LMS ratings now use Tutor's native `approved` review status when published.
- Existing private reviews stored as `1` are migrated to `approved`.
- Approved private-session ratings therefore participate in Tutor LMS's native instructor rating average/count through the tutor's `_tutor_instructor_course_id` relationship.
- Re-submitting an existing private-session rating returns it to pending moderation (`0`).


## 1.5.15 maintenance changes
- Added a real **Private Tutor Reviews** admin page and fixed the existing full-list link.
- Added an admin **Allow private-session tutor ratings** toggle.
- Added configurable tutor-response, student-proposal-response, and payment timeouts.
- Expired requests move to `failed` and remain in the database for history.
- Expired private checkout courses are deleted safely, while one-per-tutor Private Tutor Reviews courses are excluded.
- Added hourly WP-Cron maintenance plus a manual **Clean temporary courses now** action.
- Expired temporary courses are also removed from Tutor LMS cart items before deletion.


## 1.5.15
- Private Sessions and My Private Sessions use Tutor LMS calendar/check icon support with a legacy fallback.
- Confirmed, paid, and completed private sessions are exposed to Tutor LMS Calendar data for the tutor and student.

- Calendar compatibility v1.5.16: private-session events are injected into Tutor calendar REST responses across student/instructor calendar routes and nested/date-keyed payloads, while remaining available through localized Tutor data and a dedicated calendar endpoint.

## 1.5.26
- Added an Upcoming Meetings tab to the tutor Private Sessions dashboard.
- Lists paid/confirmed/completed private meetings in ascending date/time order.
- Shows student, subject, format, start/end time, duration, price, timezone, meeting details, and meeting link when available.
- Past meetings are automatically omitted after their scheduled end time.


## v1.5.29 Free Tryout
Tutors can enable a free tryout in Private Session settings, choose its duration, and choose whether one student may request it only once. Students see a Request a free tryout checkbox on the booking form. Tryout requests bypass payment and proposal/admin approval workflows; the tutor can directly approve or reject them.


## 1.5.32 Tutor Statistics
- Added a **Statistics** tab to the tutor Private Sessions dashboard.
- Tracks only private-session activity stored by this plugin; no external analytics service is used.
- Shows total requests, tutor response rate, average tutor response time, paid/confirmed sessions, completed sessions, approved tryouts, upcoming meetings, private-session revenue, and request-status breakdown.
- Added a per-session `tutor_responded_at` timestamp so response rate and response-time metrics are based on recorded tutor actions. Existing historical requests without this timestamp remain counted but are not retroactively assigned a response time.
