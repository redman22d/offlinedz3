/* Probe the classic wp-admin post editor (post.php) for our metabox. */
'use strict';
const puppeteer = require('/tmp/browsertest/node_modules/puppeteer-core');
const BASE = 'http://localhost:8899';
const COURSE_ID = process.argv[2] || '8';
const USER = process.env.TCF_USER || 'admin';
const PASS = process.env.TCF_PASS || 'admin';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium',
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
  });
  const page = await browser.newPage();
  page.on('pageerror', (e) => console.log('[pageerror]', e.message));

  await page.goto(`${BASE}/wp-login.php`, { waitUntil: 'networkidle2' });
  await page.type('#user_login', USER);
  await page.type('#user_pass', PASS);
  await Promise.all([page.waitForNavigation({ waitUntil: 'networkidle2' }), page.click('#wp-submit')]);

  const url = `${BASE}/wp-admin/post.php?post=${COURSE_ID}&action=edit&classic-editor`;
  const resp = await page.goto(url, { waitUntil: 'networkidle2', timeout: 90000 });
  console.log('HTTP', resp.status(), page.url());

  await new Promise((r) => setTimeout(r, 3000));

  const report = await page.evaluate(() => ({
    title: document.title,
    metaboxPresent: !!document.querySelector('#tcf-course-format, .tcf-metabox, [id*="tcf"]'),
    metaboxIds: Array.from(document.querySelectorAll('[id*="tcf"]')).map((e) => e.id),
    tcfInputs: Array.from(document.querySelectorAll('input[name^="tcf_"], select[name^="tcf_"]'))
      .map((e) => `${e.tagName.toLowerCase()}[name=${e.name}] value=${e.value}`),
    nonce: !!document.querySelector('input[name="tcf_metabox_nonce"]'),
    hasPublishButton: !!document.querySelector('#publish'),
    bodySnippet: (document.body.innerText || '').slice(0, 200),
  }));
  console.log(JSON.stringify(report, null, 2));

  if (report.tcfInputs.length) {
    await page.evaluate(() => {
      const set = (sel, v) => {
        const el = document.querySelector(sel);
        if (el) { el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); }
      };
      const radio = document.querySelector('input[name="tcf_course_type"][value="hybrid"]')
        || document.querySelector('select[name="tcf_course_type"]');
      if (radio && radio.tagName === 'INPUT') { radio.click(); } else { set('select[name="tcf_course_type"]', 'hybrid'); }
      set('select[name="tcf_course_format"]', 'one_to_one');
      set('input[name="tcf_session_count"]', '7');
      set('input[name="tcf_session_length"]', '0.5');
    });
    await new Promise((r) => setTimeout(r, 1200));
    await page.evaluate(() => { const b = document.querySelector('#publish'); if (b) b.click(); });
    await new Promise((r) => setTimeout(r, 8000));
    console.log('after save URL:', page.url());
  }

  await browser.close();
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
