<?php
/**
 * Reproduce the Tutor LMS course builder save request and check whether the
 * custom field meta is written.
 */

// Run as admin.
wp_set_current_user( 1 );

// 1. Create a course the way the builder's "create draft" step would.
$course_id = wp_insert_post(
	array(
		'post_title'  => 'Repro Course',
		'post_type'   => 'courses',
		'post_status' => 'draft',
	)
);
echo "course_id = {$course_id}\n";

// 2. Build the payload exactly like convertCourseDataToPayload() does,
//    including the registered slot fields flattened at the top level.
$_POST = array(
	'action'                              => 'tutor_update_course',
	tutor()->nonce                        => wp_create_nonce( tutor()->nonce_action ),
	'course_id'                           => $course_id,
	'post_title'                          => 'Repro Course',
	'post_name'                           => 'repro-course',
	'post_content'                        => 'Body',
	'post_status'                         => 'publish',
	'post_password'                       => '',
	'post_author'                         => 1,
	'pricing[type]'                       => 'free',
	'pricing[product_id]'                 => '-1',
	'course_price'                        => '0',
	'course_sale_price'                   => '0',
	'course_selling_option'               => 'one_time',
	'thumbnail_id'                        => '',
	'enable_qna'                          => 'yes',
	'is_public_course'                    => 'no',
	'course_level'                        => 'beginner',
	'course_settings[maximum_students]'   => '0',
	'course_settings[enrollment_expiry]'  => '',
	'_tutor_course_additional_data_edit'  => 'true',
	'_tutor_attachments_main_edit'        => 'true',
	// --- our custom slot fields (flat, as findSlotFields produces) ---
	'tcf_course_type'                     => 'direct',
	'tcf_course_format'                   => 'one_to_one',
	'tcf_session_count'                   => '10',
	'tcf_session_length'                  => '1.5',
);
$_REQUEST = $_POST;
$_SERVER['REQUEST_METHOD'] = 'POST';

echo "\n-- meta BEFORE --\n";
print_r(
	array(
		'_tcf_course_type'    => get_post_meta( $course_id, '_tcf_course_type', true ),
		'_tcf_course_format'  => get_post_meta( $course_id, '_tcf_course_format', true ),
		'_tcf_session_count'  => get_post_meta( $course_id, '_tcf_session_count', true ),
		'_tcf_session_length' => get_post_meta( $course_id, '_tcf_session_length', true ),
	)
);

// 3. Fire the same AJAX action the builder hits.
echo "\n-- firing wp_ajax_tutor_update_course --\n";
ob_start();
try {
	do_action( 'wp_ajax_tutor_update_course' );
} catch ( \Throwable $e ) {
	echo 'exception: ' . $e->getMessage() . "\n";
}
$response = ob_get_clean();
echo 'response: ' . substr( $response, 0, 300 ) . "\n";

echo "\n-- meta AFTER --\n";
print_r(
	array(
		'_tcf_course_type'    => get_post_meta( $course_id, '_tcf_course_type', true ),
		'_tcf_course_format'  => get_post_meta( $course_id, '_tcf_course_format', true ),
		'_tcf_session_count'  => get_post_meta( $course_id, '_tcf_session_count', true ),
		'_tcf_session_length' => get_post_meta( $course_id, '_tcf_session_length', true ),
	)
);

echo "\n-- was save_post_courses hooked? --\n";
global $wp_filter;
echo isset( $wp_filter['save_post_courses'] ) ? 'yes, ' . count( $wp_filter['save_post_courses']->callbacks ) . " callbacks\n" : "NO\n";
