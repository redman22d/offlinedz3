/**
 * Browser-side tests for Tutor LMS Course Format.
 *
 * Loads the REAL assets/js/*.js files into jsdom and asserts on their
 * behaviour against a DOM that mirrors what Tutor LMS 4.0.7 renders:
 *
 *   <div data-cy="form-field-wrapper">
 *     <label>...</label>
 *     <input name="<field name>" ...>
 *   </div>
 *
 * The course builder config fixture is produced by the PHP side
 * (tests/fixture-builder-config.json), not hand written here.
 *
 * Run: node tests/js-tests.js
 */

'use strict';

const fs = require('fs');
const path = require('path');

// jsdom is a dev-only dependency: try a normal resolve first, then the local
// sandbox install used while developing this plugin.
let JSDOM;
try {
	JSDOM = require('jsdom').JSDOM;
} catch (e) {
	JSDOM = require(process.env.TCF_JSDOM || '/tmp/jsdomtest/node_modules/jsdom').JSDOM;
}

let pass = 0;
let fail = 0;

function t(label, condition, detail) {
	if (condition) {
		pass++;
		console.log('  PASS  ' + label);
	} else {
		fail++;
		console.log('  FAIL  ' + label + (detail ? ' -> ' + detail : ''));
	}
}

function eq(label, expected, actual) {
	const ok = JSON.stringify(expected) === JSON.stringify(actual);
	t(label, ok, ok ? '' : 'expected ' + JSON.stringify(expected) + ', got ' + JSON.stringify(actual));
}

const ROOT = path.resolve(__dirname, '..');
const CONFIG = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixture-builder-config.json'), 'utf8'));
const BUILDER_JS = fs.readFileSync(path.join(ROOT, 'assets/js/tcf-course-builder.js'), 'utf8');
const METABOX_JS = fs.readFileSync(path.join(ROOT, 'assets/js/tcf-admin-metabox.js'), 'utf8');

/**
 * Build a DOM that looks like the Tutor course builder Basics section.
 *
 * @param {string} typeControl 'radio' or 'select'
 * @param {string} initialType selected course type value
 * @return {JSDOM}
 */
function makeBuilderDom(typeControl, initialType) {
	const typeOptions = CONFIG.fields[0].options;
	const formatOptions = CONFIG.fields[1].options;

	let typeMarkup;
	if (typeControl === 'radio') {
		typeMarkup = typeOptions
			.map(
				(o) =>
					'<label><input type="radio" name="tcf_course_type" value="' +
					o.value +
					'"' +
					(o.value === initialType ? ' checked' : '') +
					'/>' +
					o.label +
					'</label>'
			)
			.join('');
	} else {
		const label = (typeOptions.filter((o) => o.value === initialType)[0] || {}).label || '';
		typeMarkup = '<input name="tcf_course_type" readonly value="' + label + '"/>';
	}

	const formatLabel = (formatOptions[0] || {}).label || '';

	const html =
		'<!DOCTYPE html><html><body>' +
		'<div data-cy="form-field-wrapper">' + typeMarkup + '</div>' +
		'<div data-cy="form-field-wrapper"><label>Delivery Format</label>' +
		'<input name="tcf_course_format" readonly value="' + formatLabel + '"/></div>' +
		'<div data-cy="form-field-wrapper"><label>Sessions Number</label>' +
		'<input name="tcf_session_count" type="number"/></div>' +
		'<div data-cy="form-field-wrapper"><label>Session Length (hours)</label>' +
		'<input name="tcf_session_length" type="number"/></div>' +
		'</body></html>';

	return new JSDOM(html, { runScripts: 'outside-only' });
}

/**
 * @param {Document} doc  Document to search.
 * @param {string}   name Field name.
 * @return {Element|null}
 */
function wrapperFor(doc, name) {
	const input = doc.querySelector('input[name="' + name + '"]');
	return input ? input.closest('[data-cy="form-field-wrapper"]') : null;
}

function isVisible(el) {
	return el.style.display !== 'none';
}

function loadBuilder(dom) {
	const win = dom.window;
	const calls = [];

	// Mirror of the public Tutor LMS slot API.
	win.Tutor = {
		CourseBuilder: {
			Basic: {
				registerField(slot, field) {
					calls.push({ slot, field });
				},
				registerContent() {}
			}
		}
	};

	win.tcfCourseFormat = CONFIG;
	win.eval(BUILDER_JS);

	return calls;
}

/* --------------------------------------------------------------------- *
 * 1. Registration
 * --------------------------------------------------------------------- */

console.log('\n=== registerField() calls ===');

{
	const dom = makeBuilderDom('radio', 'prerecorded');
	const calls = loadBuilder(dom);

	eq('four fields registered', 4, calls.length);
	eq(
		'all registered into the configured slot',
		['after_settings', 'after_settings', 'after_settings', 'after_settings'],
		calls.map((c) => c.slot)
	);
	eq(
		'field names in priority order',
		['tcf_course_type', 'tcf_course_format', 'tcf_session_count', 'tcf_session_length'],
		calls.map((c) => c.field.name)
	);
	eq('course type is a radio field', 'radio', calls[0].field.type);
	eq('three type options passed through', 3, calls[0].field.options.length);
	eq('first option is the default prerecorded', 'prerecorded', calls[0].field.options[0].value);
	eq('delivery format is a select', 'select', calls[1].field.type);
	eq('format options are group / one_to_one', ['group', 'one_to_one'], calls[1].field.options.map((o) => o.value));
	eq('sessions is a number field', 'number', calls[2].field.type);
	eq('length is a number field', 'number', calls[3].field.type);
	t('labels are present', calls.every((c) => typeof c.field.label === 'string' && c.field.label.length > 0));
	eq('no validation rules by default', undefined, calls[2].field.rules);
}

/* --------------------------------------------------------------------- *
 * 2. Registration waits for window.Tutor
 * --------------------------------------------------------------------- */

console.log('\n=== registration waits for the React app to expose window.Tutor ===');

{
	const dom = makeBuilderDom('radio', 'prerecorded');
	const win = dom.window;
	const calls = [];

	win.tcfCourseFormat = CONFIG;
	win.eval(BUILDER_JS);

	eq('nothing registered before window.Tutor exists', 0, calls.length);
	t('script did not throw without window.Tutor', true);

	win.Tutor = {
		CourseBuilder: { Basic: { registerField(slot, field) { calls.push({ slot, field }); } } }
	};

	// The script polls every 100ms; give it room.
	setTimeout(() => {
		eq('registered once window.Tutor appeared', 4, calls.length);
		runVisibilityTests();
	}, 400);
}

/* --------------------------------------------------------------------- *
 * 3. Conditional visibility
 * --------------------------------------------------------------------- */

function runVisibilityTests() {
	console.log('\n=== conditional visibility (radio course type) ===');

	{
		const dom = makeBuilderDom('radio', 'prerecorded');
		loadBuilder(dom);
		const doc = dom.window.document;

		t('format hidden when prerecorded', !isVisible(wrapperFor(doc, 'tcf_course_format')));
		t('sessions hidden when prerecorded', !isVisible(wrapperFor(doc, 'tcf_session_count')));
		t('length hidden when prerecorded', !isVisible(wrapperFor(doc, 'tcf_session_length')));

		// Switch to Direct.
		doc.querySelector('input[value="direct"]').checked = true;
		doc.querySelector('input[value="prerecorded"]').checked = false;
		doc.querySelector('input[value="direct"]').dispatchEvent(
			new dom.window.Event('change', { bubbles: true })
		);

		t('format visible when direct', isVisible(wrapperFor(doc, 'tcf_course_format')));
		t('sessions visible when direct', isVisible(wrapperFor(doc, 'tcf_session_count')));
		t('length visible when direct', isVisible(wrapperFor(doc, 'tcf_session_length')));

		// Switch to Hybrid.
		doc.querySelector('input[value="direct"]').checked = false;
		doc.querySelector('input[value="hybrid"]').checked = true;
		doc.querySelector('input[value="hybrid"]').dispatchEvent(
			new dom.window.Event('change', { bubbles: true })
		);

		t('still visible when hybrid', isVisible(wrapperFor(doc, 'tcf_session_count')));

		// Back to Prerecorded.
		doc.querySelector('input[value="hybrid"]').checked = false;
		doc.querySelector('input[value="prerecorded"]').checked = true;
		doc.querySelector('input[value="prerecorded"]').dispatchEvent(
			new dom.window.Event('change', { bubbles: true })
		);

		t('hidden again when back to prerecorded', !isVisible(wrapperFor(doc, 'tcf_session_length')));
		t(
			'wrapper is tagged for debugging',
			wrapperFor(doc, 'tcf_session_length').getAttribute('data-tcf-field') === 'tcf_session_length'
		);
		t(
			'hidden wrapper is aria-hidden',
			wrapperFor(doc, 'tcf_session_length').getAttribute('aria-hidden') === 'true'
		);
	}

	console.log('\n=== conditional visibility (select course type, label fallback) ===');

	{
		const dom = makeBuilderDom('select', 'prerecorded');
		loadBuilder(dom);
		const doc = dom.window.document;

		t('hidden when the select shows Prerecorded', !isVisible(wrapperFor(doc, 'tcf_session_count')));

		// Tutor's select renders the option LABEL in a read-only input.
		doc.querySelector('input[name="tcf_course_type"]').value = 'Hybrid (Prerecorded + Direct)';
		doc.dispatchEvent(new dom.window.Event('click', { bubbles: true }));

		t('visible when the select shows Hybrid', isVisible(wrapperFor(doc, 'tcf_session_count')));

		doc.querySelector('input[name="tcf_course_type"]').value = 'Direct';
		doc.dispatchEvent(new dom.window.Event('click', { bubbles: true }));
		t('visible when the select shows Direct', isVisible(wrapperFor(doc, 'tcf_session_length')));

		doc.querySelector('input[name="tcf_course_type"]').value = 'Prerecorded';
		doc.dispatchEvent(new dom.window.Event('click', { bubbles: true }));
		t('hidden again when the select shows Prerecorded', !isVisible(wrapperFor(doc, 'tcf_session_count')));
	}

	console.log('\n=== nothing is hidden before the fields mount ===');

	{
		const dom = new JSDOM('<!DOCTYPE html><html><body><div id="root"></div></body></html>', {
			runScripts: 'outside-only'
		});
		loadBuilder(dom);
		t('no error on an empty DOM', true);
		t('no wrappers tagged yet', dom.window.document.querySelectorAll('[data-tcf-field]').length === 0);
	}

	runMetaboxTests();
}

/* --------------------------------------------------------------------- *
 * 4. wp-admin metabox behaviour (fixtures rendered by PHP)
 * --------------------------------------------------------------------- */

const tick = () => new Promise((resolve) => setTimeout(resolve, 30));

async function runMetaboxTests() {
	console.log('\n=== wp-admin metabox script ===');

	const liveHtml = fs.readFileSync(path.join(__dirname, 'fixture-metabox-live.html'), 'utf8');
	const preHtml = fs.readFileSync(path.join(__dirname, 'fixture-metabox-prerecorded.html'), 'utf8');

	{
		const dom = new JSDOM('<!DOCTYPE html><html><body>' + liveHtml + '</body></html>', {
			runScripts: 'outside-only'
		});
		dom.window.eval(METABOX_JS);
		await tick();

		const box = dom.window.document.querySelector('.tcf-metabox');
		const live = box.querySelector('.tcf-live-only');
		const select = box.querySelector('select[name="tcf_course_type"]');

		t('live block visible for a direct course', live.hidden === false);
		t('live inputs enabled', !live.querySelector('input[name="tcf_session_count"]').disabled);

		select.value = 'prerecorded';
		select.dispatchEvent(new dom.window.Event('change', { bubbles: true }));

		t('live block hidden after switching to prerecorded', live.hidden === true);
		t('sessions input disabled so it is not submitted', live.querySelector('input[name="tcf_session_count"]').disabled);
		t('length input disabled too', live.querySelector('input[name="tcf_session_length"]').disabled);
		t('format select disabled too', live.querySelector('select[name="tcf_course_format"]').disabled);

		select.value = 'hybrid';
		select.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
		t('live block shown again for hybrid', live.hidden === false);
		t('inputs re-enabled', !live.querySelector('input[name="tcf_session_count"]').disabled);
	}

	{
		const dom = new JSDOM('<!DOCTYPE html><html><body>' + preHtml + '</body></html>', {
			runScripts: 'outside-only'
		});
		dom.window.eval(METABOX_JS);
		await tick();

		const box = dom.window.document.querySelector('.tcf-metabox');
		const live = box.querySelector('.tcf-live-only');

		t('live block starts hidden for a prerecorded course', live.hidden === true);
		t('inputs start disabled', live.querySelector('input[name="tcf_session_count"]').disabled);

		// Regression: PHP renders the `hidden` attribute for prerecorded courses.
		// Clearing only style.display left the block invisible after switching
		// to a live type.
		const select = box.querySelector('select[name="tcf_course_type"]');
		select.value = 'direct';
		select.dispatchEvent(new dom.window.Event('change', { bubbles: true }));

		t('live block revealed after switching prerecorded -> direct', live.hidden === false);
		t('inputs enabled after switching prerecorded -> direct', !live.querySelector('input[name="tcf_session_count"]').disabled);
	}

	summary();
}

function summary() {
	console.log('\n==========================================');
	console.log('  ' + pass + ' passed, ' + fail + ' failed');
	console.log('==========================================\n');
	process.exit(fail > 0 ? 1 : 0);
}
