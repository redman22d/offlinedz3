/* Verify the custom fields sit after the Course Description and before Options. */
'use strict';
const puppeteer = require('/tmp/browsertest/node_modules/puppeteer-core');
const BASE = 'http://localhost:8899';
const COURSE_ID = process.argv[2] || '8';
const USER = process.env.TCF_USER || 'admin';
const PASS = process.env.TCF_PASS || 'admin';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium',
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1600, height: 1400 });

  await page.goto(`${BASE}/wp-login.php`, { waitUntil: 'networkidle2' });
  await page.type('#user_login', USER);
  await page.type('#user_pass', PASS);
  await Promise.all([page.waitForNavigation({ waitUntil: 'networkidle2' }), page.click('#wp-submit')]);

  await page.goto(`${BASE}/wp-admin/admin.php?page=create-course&course_id=${COURSE_ID}`, {
    waitUntil: 'networkidle2', timeout: 90000,
  });
  await new Promise((r) => setTimeout(r, 12000));

  const order = await page.evaluate(() => {
    // Walk the DOM in document order and record landmarks we care about.
    const marks = [];
    const label = (el) => {
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      return t.slice(0, 45);
    };

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    let n;
    while ((n = walker.nextNode())) {
      const tag = n.tagName.toLowerCase();

      // Our fields.
      const name = n.getAttribute && n.getAttribute('name');
      if (name && name.indexOf('tcf_') === 0 && n.type !== 'hidden') {
        marks.push({ y: n.getBoundingClientRect().top + window.scrollY, what: `FIELD ${name}` });
        continue;
      }
      if (tag === 'textarea' && /wp-editor|tinymce|description/i.test(n.id || '')) {
        marks.push({ y: n.getBoundingClientRect().top + window.scrollY, what: `TEXTAREA #${n.id}` });
        continue;
      }
      if (n.id === 'wp-post_content-wrap' || n.classList.contains('wp-editor-wrap')) {
        marks.push({ y: n.getBoundingClientRect().top + window.scrollY, what: `EDITOR ${n.id || n.className}` });
        continue;
      }
      // Headings / labels of interest.
      if (/^(h1|h2|h3|h4|h5|h6|legend|p|span|div)$/.test(tag)) {
        const own = Array.from(n.childNodes)
          .filter((c) => c.nodeType === 3)
          .map((c) => c.textContent.trim()).join(' ');
        const txt = (own || '').replace(/\s+/g, ' ').trim();
        if (/^[A-Z][A-Za-z0-9 +()\/-]{2,40}$/.test(txt) && txt.length < 42) {
          marks.push({ y: n.getBoundingClientRect().top + window.scrollY, what: `LABEL "${txt}"` });
        }
      }
    }

    // De-dupe identical entries, then sort by vertical position.
    const seen = new Set();
    return marks
      .filter((m) => { const k = m.what + Math.round(m.y); if (seen.has(k)) return false; seen.add(k); return true; })
      .sort((a, b) => a.y - b.y)
      .map((m) => `${String(Math.round(m.y)).padStart(6)}  ${m.what}`);
  });

  console.log('=== DOCUMENT ORDER (top -> bottom) ===');
  console.log(order.join('\n'));

  // Every form field wrapper Tutor renders, in order, with its label.
  const fields = await page.evaluate(() => {
    const out = [];
    document.querySelectorAll('[data-cy="form-field-wrapper"]').forEach((w) => {
      const r = w.getBoundingClientRect();
      if (r.height === 0) return;
      const lbl = w.querySelector('label, legend');
      const inp = w.querySelector('input,select,textarea');
      out.push({
        y: Math.round(r.top + window.scrollY),
        x: Math.round(r.left + window.scrollX),
        w: Math.round(r.width),
        label: lbl ? lbl.textContent.replace(/\s+/g, ' ').trim().slice(0, 40) : '(no label)',
        name: inp ? (inp.getAttribute('name') || '') : '',
      });
    });
    return out.sort((a, b) => a.y - b.y);
  });
  console.log('\n=== FORM FIELDS IN ORDER ===');
  fields.forEach((f) => console.log('y=' + String(f.y).padStart(6), 'x=' + String(f.x).padStart(5), 'w=' + String(f.w).padStart(5), '|', f.label.padEnd(32), '|', f.name));

  // Is our slot content one contiguous block?
  const blocks = await page.evaluate(() => {
    const wraps = Array.from(document.querySelectorAll('[data-cy="form-field-wrapper"]'))
      .filter((w) => w.getBoundingClientRect().height > 0);
    return wraps.map((w) => {
      const inp = w.querySelector('input,select,textarea');
      const nm = inp ? (inp.getAttribute('name') || '') : '';
      // nearest ancestor chain, condensed
      let chain = [];
      let el = w.parentElement;
      for (let i = 0; i < 4 && el; i++) { chain.push(el.tagName.toLowerCase() + (el.className ? '.' + String(el.className).split(' ').slice(0,1).join('.') : '')); el = el.parentElement; }
      return { name: nm, chain: chain.join(' < ') };
    });
  });
  console.log('\n=== PARENT CHAIN (first 12 visible fields) ===');
  blocks.slice(0, 12).forEach((b) => console.log(String(b.name).padEnd(22), '::', b.chain.slice(0, 110)));

  await browser.close();
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
