#!/usr/bin/env bash
#
# Run every test suite for Tutor LMS Course Format.
#
#   bash tests/run-all.sh
#
set -u

cd "$(dirname "$0")/.." || exit 1

status=0

echo "=============================================="
echo " PHP lint"
echo "=============================================="
lint_failed=0
while IFS= read -r file; do
	out=$(php -l "$file" 2>&1)
	if [ $? -ne 0 ]; then
		echo "$out"
		lint_failed=1
	fi
done < <(find . -name '*.php' -not -path './node_modules/*' | sort)
if [ "$lint_failed" -eq 0 ]; then
	echo "  OK  no syntax errors"
else
	status=1
fi

echo
echo "=============================================="
echo " JS syntax"
echo "=============================================="
js_failed=0
while IFS= read -r file; do
	if ! node --check "$file"; then
		js_failed=1
	fi
done < <(find ./assets/js -name '*.js' | sort)
if [ "$js_failed" -eq 0 ]; then
	echo "  OK  no syntax errors"
else
	status=1
fi

echo
echo "=============================================="
echo " PHP suite"
echo "=============================================="
php tests/run-tests.php || status=1

echo
echo "=============================================="
echo " Browser suite (regenerates fixtures first)"
echo "=============================================="
php tests/generate-fixtures.php >/dev/null || status=1
node tests/js-tests.js || status=1

echo
if [ "$status" -eq 0 ]; then
	echo "ALL SUITES PASSED"
else
	echo "SOME SUITES FAILED"
fi
exit "$status"
