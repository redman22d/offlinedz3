<?php
/**
 * Standalone test harness for Tutor LMS Course Format.
 *
 * It stubs the WordPress + Tutor LMS surface the plugin touches, then loads the
 * REAL plugin files and exercises their code paths:
 *
 *   - tcf_save_course_format()                        (sanitizing + meta writes)
 *   - TCF_Course_Builder::save()                      (save_post_courses handler)
 *   - TCF_Course_Builder::add_fields_to_details_response()
 *   - TCF_Course_Builder::get_js_config()             (payload sent to the JS)
 *   - TCF_Frontend::learning_area_rows() / legacy_sidebar_rows()
 *   - TCF_Admin_Metabox::render()
 *
 * Run: php tests/run-tests.php
 *
 * @package TutorCourseFormat
 */

// phpcs:disable
error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

define( 'ABSPATH', __DIR__ . '/fake-abspath/' );

/* --------------------------------------------------------------------- *
 * Minimal WordPress shim
 * --------------------------------------------------------------------- */

$GLOBALS['tcf_meta']       = array();
$GLOBALS['tcf_filters']    = array();
$GLOBALS['tcf_actions']    = array();
$GLOBALS['tcf_scripts']    = array();
$GLOBALS['tcf_localized']  = array();
$GLOBALS['tcf_metaboxes']  = array();
$GLOBALS['tcf_styles']     = array();
$GLOBALS['tcf_rest']       = array();
$GLOBALS['tcf_caps']       = true;
$GLOBALS['tcf_user_id']     = 1;
$GLOBALS['tcf_tutor_can_edit'] = true;

class WP_Post {
	public $ID;
	public $post_type = 'courses';
	public function __construct( $id ) { $this->ID = $id; }
}

function add_action( $hook, $cb, $prio = 10, $args = 1 ) { $GLOBALS['tcf_actions'][ $hook ][] = $cb; return true; }
function add_filter( $hook, $cb, $prio = 10, $args = 1 ) { $GLOBALS['tcf_filters'][ $hook ][] = $cb; return true; }
function remove_action() { return true; }
function remove_filter() { return true; }
function did_action( $hook ) { return isset( $GLOBALS['tcf_actions'][ $hook ] ) ? count( $GLOBALS['tcf_actions'][ $hook ] ) : 0; }

function apply_filters( $hook, $value ) {
	$args = func_get_args();
	array_shift( $args );
	if ( empty( $GLOBALS['tcf_filters'][ $hook ] ) ) {
		return $value;
	}
	foreach ( $GLOBALS['tcf_filters'][ $hook ] as $cb ) {
		$args[0] = call_user_func_array( $cb, $args );
	}
	return $args[0];
}

function do_action( $hook ) {
	$args = func_get_args();
	array_shift( $args );
	if ( empty( $GLOBALS['tcf_actions'][ $hook ] ) ) {
		return;
	}
	foreach ( $GLOBALS['tcf_actions'][ $hook ] as $cb ) {
		call_user_func_array( $cb, $args );
	}
}

function get_post_meta( $id, $key, $single = false ) {
	$store = $GLOBALS['tcf_meta'][ $id ] ?? array();
	if ( ! array_key_exists( $key, $store ) ) {
		return $single ? '' : array();
	}
	return $single ? $store[ $key ] : array( $store[ $key ] );
}

function update_post_meta( $id, $key, $value ) {
	$GLOBALS['tcf_meta'][ $id ][ $key ] = $value;
	return true;
}

function delete_post_meta( $id, $key ) {
	unset( $GLOBALS['tcf_meta'][ $id ][ $key ] );
	return true;
}

function __( $text, $domain = null ) { return $text; }
function _e( $text, $domain = null ) { echo $text; }
function esc_html__( $text, $domain = null ) { return htmlspecialchars( $text, ENT_QUOTES ); }
function esc_html_e( $text, $domain = null ) { echo htmlspecialchars( $text, ENT_QUOTES ); }
function esc_attr__( $text, $domain = null ) { return htmlspecialchars( $text, ENT_QUOTES ); }
function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_attr( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_js( $text ) { return str_replace( array( "\r", "\n", "'", '"' ), array( '', '', "\'", '\"' ), (string) $text ); }
function wp_kses_post( $text ) { return $text; }
function wp_json_encode( $data ) { return json_encode( $data ); }
function sanitize_text_field( $text ) { return trim( strip_tags( (string) $text ) ); }
function sanitize_key( $text ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $text ) ); }
function wp_unslash( $value ) { return is_string( $value ) ? stripslashes( $value ) : $value; }
function wp_slash( $value ) { return $value; }
function absint( $value ) { return abs( (int) $value ); }
function wp_nonce_field( $action, $name ) { echo '<input type="hidden" name="' . $name . '" value="nonce-' . $action . '" />'; }
function wp_verify_nonce( $nonce, $action ) { return $nonce === 'nonce-' . $action ? 1 : false; }
function wp_create_nonce( $action ) { return 'nonce-' . $action; }
function wp_is_post_revision( $id ) { return false; }
function wp_is_post_autosave( $id ) { return false; }
function current_user_can( $cap, $id = 0 ) {
	$caps = $GLOBALS['tcf_caps'];
	if ( is_array( $caps ) ) {
		return in_array( $cap, $caps, true );
	}
	return (bool) $caps;
}
function get_current_user_id() { return (int) ( $GLOBALS['tcf_user_id'] ?? 0 ); }
/**
 * Minimal stand-in for Tutor's Utils class. Only the members this plugin
 * touches are implemented; `tcf_tutor_can_edit` drives the answer.
 */
class TCF_Shim_Tutor_Utils {
	public function can_user_edit_course( $user_id, $course_id ) {
		return (bool) ( $GLOBALS['tcf_tutor_can_edit'] ?? false );
	}
}
function tutor_utils() { return new TCF_Shim_Tutor_Utils(); }
function get_the_ID() { return 0; }
function selected( $a, $b, $echo = true ) { $r = ( (string) $a === (string) $b ) ? " selected='selected'" : ''; if ( $echo ) { echo $r; } return $r; }
function checked( $a, $b, $echo = true ) { return selected( $a, $b, $echo ); }
function _n( $single, $plural, $number, $domain = null ) { return 1 === (int) $number ? $single : $plural; }
function number_format_i18n( $number, $decimals = 0 ) { return number_format( $number, $decimals ); }
function plugin_dir_path( $file ) { return rtrim( dirname( $file ), '/' ) . '/'; }
function plugin_dir_url( $file ) { return 'https://example.test/wp-content/plugins/tutor-course-format/'; }
function plugin_basename( $file ) { return 'tutor-course-format/tutor-course-format.php'; }
function load_plugin_textdomain() { return true; }
function register_activation_hook() { return true; }
function flush_rewrite_rules() { return true; }
function get_current_screen() { return (object) array( 'post_type' => 'courses' ); }

function wp_script_is( $handle, $state = 'enqueued' ) {
	return isset( $GLOBALS['tcf_scripts'][ $handle ] );
}
function wp_enqueue_script( $handle, $src = '', $deps = array(), $ver = false, $footer = false ) {
	$GLOBALS['tcf_scripts'][ $handle ] = compact( 'src', 'deps', 'ver', 'footer' );
	return true;
}
function wp_enqueue_style( $handle, $src = '', $deps = array(), $ver = false ) {
	$GLOBALS['tcf_styles'][ $handle ] = compact( 'src', 'deps', 'ver' );
	return true;
}
function wp_localize_script( $handle, $name, $data ) {
	$GLOBALS['tcf_localized'][ $name ] = $data;
	return true;
}
function add_meta_box( $id, $title, $cb, $screen, $context = 'advanced', $priority = 'default' ) {
	$GLOBALS['tcf_metaboxes'][ $id ] = compact( 'title', 'cb', 'screen', 'context', 'priority' );
	return true;
}
function register_rest_field( $type, $name, $args ) {
	$GLOBALS['tcf_rest'][ $type . ':' . $name ] = $args;
	return true;
}
function add_action_once() {}

/* Tutor LMS shim */
define( 'TUTOR_VERSION', '4.0.7' );

function tutor() {
	static $instance = null;
	if ( null === $instance ) {
		$instance                 = new stdClass();
		$instance->course_post_type = 'courses';
		$instance->has_pro          = false;
	}
	return $instance;
}

/* --------------------------------------------------------------------- *
 * Tiny assertion helper
 * --------------------------------------------------------------------- */

$GLOBALS['tcf_pass'] = 0;
$GLOBALS['tcf_fail'] = 0;

function t( $label, $condition, $detail = '' ) {
	if ( $condition ) {
		$GLOBALS['tcf_pass']++;
		echo "  PASS  {$label}\n";
	} else {
		$GLOBALS['tcf_fail']++;
		echo "  FAIL  {$label}" . ( '' !== $detail ? " -> {$detail}" : '' ) . "\n";
	}
}

function eq( $label, $expected, $actual ) {
	$ok = $expected === $actual;
	t( $label, $ok, $ok ? '' : 'expected ' . var_export( $expected, true ) . ', got ' . var_export( $actual, true ) );
}

/* --------------------------------------------------------------------- *
 * Load the plugin
 * --------------------------------------------------------------------- */

echo "\n=== Loading plugin ===\n";
require dirname( __DIR__ ) . '/tutor-course-format.php';

t( 'TCF_META_TYPE constant defined', defined( 'TCF_META_TYPE' ) );
t( 'tcf_is_tutor_active() true with stub', tcf_is_tutor_active() === true );
eq( 'course post type resolves to courses', 'courses', tcf_course_post_type() );

TCF_Plugin::instance()->init();
do_action( 'rest_api_init' );

t( 'save_post_courses hook registered', ! empty( $GLOBALS['tcf_actions']['save_post_courses'] ) );
t( 'tutor_course_details_response hook registered', ! empty( $GLOBALS['tcf_filters']['tutor_course_details_response'] ) );
t( 'learning area filter registered', ! empty( $GLOBALS['tcf_filters']['tutor_learning_area_course_info_metadata'] ) );
t( 'legacy sidebar filter registered', ! empty( $GLOBALS['tcf_filters']['tutor/course/single/sidebar/metadata'] ) );
t( 'REST field registered for courses', isset( $GLOBALS['tcf_rest']['courses:course_format'] ) );
t( 'course builder enqueue hooked into Tutor action', ! empty( $GLOBALS['tcf_actions']['tutor_before_course_builder_load'] ) );

/* --------------------------------------------------------------------- *
 * Sanitizers
 * --------------------------------------------------------------------- */

echo "\n=== Sanitizers ===\n";
eq( 'valid type kept', 'direct', tcf_sanitize_course_type( 'direct' ) );
eq( 'unknown type falls back to prerecorded', 'prerecorded', tcf_sanitize_course_type( 'bogus' ) );
eq( 'empty type falls back to prerecorded', 'prerecorded', tcf_sanitize_course_type( '' ) );
eq( 'array type falls back to prerecorded', 'prerecorded', tcf_sanitize_course_type( array( 'x' ) ) );
eq( 'valid format kept', 'one_to_one', tcf_sanitize_course_format( 'one_to_one' ) );
eq( 'unknown format emptied', '', tcf_sanitize_course_format( 'trio' ) );
eq( 'sessions natural number', 12, tcf_sanitize_session_count( '12' ) );
eq( 'sessions floor decimals', 7, tcf_sanitize_session_count( '7.9' ) );
eq( 'sessions rejects negative', 0, tcf_sanitize_session_count( '-5' ) );
eq( 'sessions rejects text', 0, tcf_sanitize_session_count( 'twelve' ) );
eq( 'sessions caps at max', 999, tcf_sanitize_session_count( '5000' ) );
eq( 'length decimal kept', 1.5, tcf_sanitize_session_length( '1.5' ) );
eq( 'length comma decimal normalised', 2.25, tcf_sanitize_session_length( '2,25' ) );
eq( 'length caps at max', 24.0, tcf_sanitize_session_length( '100' ) );
eq( 'length rejects text', 0.0, tcf_sanitize_session_length( 'abc' ) );
eq( 'hours 1.50 formats as 1.5', '1.5', tcf_format_hours( 1.5 ) );
eq( 'hours 2 formats as 2', '2', tcf_format_hours( 2 ) );
eq( 'hours 0 formats empty', '', tcf_format_hours( 0 ) );

/* --------------------------------------------------------------------- *
 * Saving: live course
 * --------------------------------------------------------------------- */

echo "\n=== tcf_save_course_format(): direct course ===\n";

$saved = tcf_save_course_format( 101, array(
	TCF_FIELD_TYPE     => 'direct',
	TCF_FIELD_FORMAT   => 'one_to_one',
	TCF_FIELD_SESSIONS => '10',
	TCF_FIELD_LENGTH   => '1.5',
) );

eq( 'saved type', 'direct', $saved['type'] );
eq( 'saved format', 'one_to_one', $saved['format'] );
eq( 'saved sessions', 10, $saved['session'] );
eq( 'saved length', 1.5, $saved['length'] );
eq( 'meta type written', 'direct', get_post_meta( 101, TCF_META_TYPE, true ) );
eq( 'meta format written', 'one_to_one', get_post_meta( 101, TCF_META_FORMAT, true ) );
eq( 'meta sessions written', 10, get_post_meta( 101, TCF_META_SESSIONS, true ) );
eq( 'meta length written', 1.5, get_post_meta( 101, TCF_META_LENGTH, true ) );
t( 'has live sessions', tcf_course_has_live_sessions( 101 ) === true );

/* --------------------------------------------------------------------- *
 * Saving: prerecorded prunes dependent meta
 * --------------------------------------------------------------------- */

echo "\n=== tcf_save_course_format(): switching back to prerecorded prunes meta ===\n";

tcf_save_course_format( 101, array(
	TCF_FIELD_TYPE     => 'prerecorded',
	TCF_FIELD_FORMAT   => 'one_to_one',
	TCF_FIELD_SESSIONS => '10',
	TCF_FIELD_LENGTH   => '1.5',
) );

eq( 'type is prerecorded', 'prerecorded', get_post_meta( 101, TCF_META_TYPE, true ) );
eq( 'format meta deleted', '', get_post_meta( 101, TCF_META_FORMAT, true ) );
eq( 'sessions meta deleted', '', get_post_meta( 101, TCF_META_SESSIONS, true ) );
eq( 'length meta deleted', '', get_post_meta( 101, TCF_META_LENGTH, true ) );
t( 'no live sessions', tcf_course_has_live_sessions( 101 ) === false );
eq( 'format getter empty when prerecorded', '', tcf_get_course_format( 101 ) );
eq( 'sessions getter 0 when prerecorded', 0, tcf_get_session_count( 101 ) );

/* --------------------------------------------------------------------- *
 * Defaults for a course that has never been saved
 * --------------------------------------------------------------------- */

echo "\n=== Defaults ===\n";
eq( 'untouched course defaults to prerecorded', 'prerecorded', tcf_get_course_type( 999 ) );
t( 'untouched course has no live sessions', tcf_course_has_live_sessions( 999 ) === false );

/* Live course with no explicit format defaults to group */
tcf_save_course_format( 555, array(
	TCF_FIELD_TYPE     => 'hybrid',
	TCF_FIELD_FORMAT   => '',
	TCF_FIELD_SESSIONS => '0',
	TCF_FIELD_LENGTH   => '0',
) );
eq( 'hybrid without format defaults to group', 'group', tcf_get_course_format( 555 ) );

/* --------------------------------------------------------------------- *
 * save_post_courses handler
 * --------------------------------------------------------------------- */

echo "\n=== TCF_Course_Builder::save() via \$_POST ===\n";

$builder = new TCF_Course_Builder();

$_POST = array(
	TCF_FIELD_TYPE     => 'hybrid',
	TCF_FIELD_FORMAT   => 'group',
	TCF_FIELD_SESSIONS => '24',
	TCF_FIELD_LENGTH   => '0.75',
);
$builder->save( 202, new WP_Post( 202 ), true );

eq( 'handler saved type', 'hybrid', get_post_meta( 202, TCF_META_TYPE, true ) );
eq( 'handler saved format', 'group', get_post_meta( 202, TCF_META_FORMAT, true ) );
eq( 'handler saved sessions', 24, get_post_meta( 202, TCF_META_SESSIONS, true ) );
eq( 'handler saved length', 0.75, get_post_meta( 202, TCF_META_LENGTH, true ) );

echo "\n=== Handler ignores unrelated saves ===\n";

$_POST = array( 'post_title' => 'Something else' );
$builder->save( 202, new WP_Post( 202 ), true );
eq( 'meta untouched by unrelated save', 'hybrid', get_post_meta( 202, TCF_META_TYPE, true ) );

echo "\n=== Handler rejects bad nonce ===\n";

$_POST = array(
	'tcf_metabox_nonce' => 'wrong',
	TCF_FIELD_TYPE      => 'direct',
	TCF_FIELD_FORMAT    => 'one_to_one',
	TCF_FIELD_SESSIONS  => '3',
	TCF_FIELD_LENGTH    => '2',
);
$builder->save( 303, new WP_Post( 303 ), true );
eq( 'bad nonce does not write', '', get_post_meta( 303, TCF_META_TYPE, true ) );

echo "\n=== Handler accepts valid nonce ===\n";

$_POST = array(
	'tcf_metabox_nonce' => wp_create_nonce( 'tcf_save_course_format' ),
	TCF_FIELD_TYPE      => 'direct',
	TCF_FIELD_FORMAT    => 'one_to_one',
	TCF_FIELD_SESSIONS  => '3',
	TCF_FIELD_LENGTH    => '2',
);
$builder->save( 303, new WP_Post( 303 ), true );
eq( 'valid nonce writes type', 'direct', get_post_meta( 303, TCF_META_TYPE, true ) );
eq( 'valid nonce writes sessions', 3, get_post_meta( 303, TCF_META_SESSIONS, true ) );

echo "\n=== Handler respects capability check ===\n";

$_POST = array(
	TCF_FIELD_TYPE     => 'direct',
	TCF_FIELD_FORMAT   => 'group',
	TCF_FIELD_SESSIONS => '5',
	TCF_FIELD_LENGTH   => '1',
);

// Neither gate passes -> nothing may be written.
$GLOBALS['tcf_caps']            = false;
$GLOBALS['tcf_tutor_can_edit']  = false;
$builder->save( 404, new WP_Post( 404 ), true );
eq( 'no capability, nothing written', '', get_post_meta( 404, TCF_META_TYPE, true ) );

/*
 * Regression: an instructor editing their own PUBLISHED course.
 *
 * The `courses` CPT uses map_meta_cap, so editing a published course also
 * demands `edit_published_tutor_courses` - a capability Tutor never grants the
 * tutor_instructor role. Gating on current_user_can('edit_post') alone made
 * should_save() return false and the field data was silently dropped, even
 * though Tutor's own ajax_update_course accepted the very same request.
 */
$GLOBALS['tcf_caps']           = array( 'edit_tutor_course', 'edit_tutor_courses' ); // no edit_published_*
$GLOBALS['tcf_tutor_can_edit'] = true;   // tutor_utils()->can_user_edit_course()
$builder->save( 505, new WP_Post( 505 ), true );
eq( 'instructor + published course: type saved',     'direct',     get_post_meta( 505, TCF_META_TYPE, true ) );
eq( 'instructor + published course: format saved',   'group',       get_post_meta( 505, TCF_META_FORMAT, true ) );
eq( 'instructor + published course: sessions saved', 5,            get_post_meta( 505, TCF_META_SESSIONS, true ) );
eq( 'instructor + published course: length saved',   1.0,          get_post_meta( 505, TCF_META_LENGTH, true ) );

// Core capability alone must still be enough (admins, editors).
$GLOBALS['tcf_caps']           = true;
$GLOBALS['tcf_tutor_can_edit'] = false;
$builder->save( 606, new WP_Post( 606 ), true );
eq( 'core capability alone still saves', 'direct', get_post_meta( 606, TCF_META_TYPE, true ) );

$GLOBALS['tcf_caps']           = true;
$GLOBALS['tcf_tutor_can_edit'] = true;

/* --------------------------------------------------------------------- *
 * Course details response filter
 * --------------------------------------------------------------------- */

echo "\n=== tutor_course_details_response ===\n";

$response = $builder->add_fields_to_details_response( array(
	'ID'           => 202,
	'post_title'   => 'Test',
	'course_level' => 'beginner',
) );

eq( 'response keeps existing keys', 'beginner', $response['course_level'] );
eq( 'response type', 'hybrid', $response[ TCF_FIELD_TYPE ] );
eq( 'response format', 'group', $response[ TCF_FIELD_FORMAT ] );
eq( 'response sessions as string', '24', $response[ TCF_FIELD_SESSIONS ] );
eq( 'response length as string', '0.75', $response[ TCF_FIELD_LENGTH ] );

$empty = $builder->add_fields_to_details_response( array( 'ID' => 999 ) );
eq( 'prerecorded response type', 'prerecorded', $empty[ TCF_FIELD_TYPE ] );
eq( 'prerecorded response format prefilled', 'group', $empty[ TCF_FIELD_FORMAT ] );
eq( 'prerecorded response sessions empty', '', $empty[ TCF_FIELD_SESSIONS ] );
eq( 'prerecorded response length empty', '', $empty[ TCF_FIELD_LENGTH ] );

$noId = $builder->add_fields_to_details_response( array( 'post_title' => 'x' ) );
t( 'response without ID is returned unchanged', ! isset( $noId[ TCF_FIELD_TYPE ] ) );

/* --------------------------------------------------------------------- *
 * JS config
 * --------------------------------------------------------------------- */

echo "\n=== JS config sent to the course builder ===\n";

$builder->enqueue();
t( 'script enqueued', isset( $GLOBALS['tcf_scripts']['tcf-course-builder'] ) );
eq( 'script depends on tutor-course-builder', array( 'tutor-course-builder' ), $GLOBALS['tcf_scripts']['tcf-course-builder']['deps'] );
t( 'config localized', isset( $GLOBALS['tcf_localized']['tcfCourseFormat'] ) );

$config = $GLOBALS['tcf_localized']['tcfCourseFormat'];
eq( 'slot defaults to after_description', 'after_description', $config['slot'] );
eq( 'four fields registered', 4, count( $config['fields'] ) );

$names = array_column( $config['fields'], 'name' );
eq( 'field names', array( TCF_FIELD_TYPE, TCF_FIELD_FORMAT, TCF_FIELD_SESSIONS, TCF_FIELD_LENGTH ), $names );

$typeField = $config['fields'][0];
eq( 'course type field is a radio', 'radio', $typeField['type'] );
eq( 'three course type options', 3, count( $typeField['options'] ) );
eq( 'first option is prerecorded', 'prerecorded', $typeField['options'][0]['value'] );
eq( 'option labels present', 'Prerecorded', $typeField['options'][0]['label'] );
eq( 'hybrid label', 'Hybrid (Prerecorded + Direct)', $typeField['options'][2]['label'] );

$formatField = $config['fields'][1];
eq( 'format field is a select', 'select', $formatField['type'] );
eq( 'format options', array( 'group', 'one_to_one' ), array_column( $formatField['options'], 'value' ) );
eq( 'group label', 'Group study', $formatField['options'][0]['label'] );
eq( '1v1 label', '1v1 study', $formatField['options'][1]['label'] );

eq( 'sessions field is a number', 'number', $config['fields'][2]['type'] );
eq( 'length field is a number', 'number', $config['fields'][3]['type'] );
eq( 'live types', array( 'direct', 'hybrid' ), $config['liveTypes'] );
eq( 'requireLive off by default', false, $config['requireLive'] );

$priorities = array_column( $config['fields'], 'priority' );
eq( 'priorities ordered', array( 10, 20, 30, 40 ), $priorities );

/* --------------------------------------------------------------------- *
 * Front end display
 * --------------------------------------------------------------------- */

echo "\n=== Front end rows (hybrid course 202) ===\n";

$frontend = new TCF_Frontend();

// Course 202: hybrid, group study, 24 sessions, 0.75 h each.
$legacy = $frontend->legacy_sidebar_rows( array(), 202 );
eq( 'hybrid: three rows', 3, count( $legacy ) );
eq( 'row 1 label', 'Course Type', $legacy[0]['label'] );
eq( 'row 1 value', 'Direct lessons and prerecorded', $legacy[0]['value'] );
eq( 'row 1 legacy icon', 'tutor-icon-interactive', $legacy[0]['icon_class'] );
eq( 'row 2 label', 'Study Type', $legacy[1]['label'] );
eq( 'row 2 value', 'Group study', $legacy[1]['value'] );
eq( 'row 2 legacy icon', 'tutor-icon-user-group', $legacy[1]['icon_class'] );
eq( 'row 3 label', 'Number', $legacy[2]['label'] );
eq( 'row 3 value', '24 live sessions for 0.75 hours per session', $legacy[2]['value'] );
eq( 'row 3 legacy icon', 'tutor-icon-calender', $legacy[2]['icon_class'] );

$la = $frontend->learning_area_rows( array(), 202 );
eq( 'learning area rows count', 3, count( $la ) );
eq( 'learning area row 1 title', 'Course Type', $la[0]['title'] );
eq( 'learning area row 1 icon', 'lesson', $la[0]['icon'] );
eq( 'learning area row 1 content', 'Direct lessons and prerecorded', $la[0]['content'] );
eq( 'learning area row 2 title', 'Study Type', $la[1]['title'] );
eq( 'learning area row 2 icon', 'user-circle', $la[1]['icon'] );
eq( 'learning area row 2 content', 'Group study', $la[1]['content'] );
eq( 'learning area row 3 title', 'Number', $la[2]['title'] );
eq( 'learning area row 3 icon', 'calendar', $la[2]['icon'] );
eq( 'learning area row 3 content', '24 live sessions for 0.75 hours per session', $la[2]['content'] );
t( 'learning area row has no legacy keys', ! isset( $la[0]['icon_class'] ) && ! isset( $la[0]['value'] ) );

echo "\n=== Front end rows (1v1 direct course 303) ===\n";

// Course 303: direct, 1v1, 3 sessions, 2 h each.
$one = $frontend->legacy_sidebar_rows( array(), 303 );
eq( 'direct rows count', 3, count( $one ) );
eq( 'direct type value', 'Direct lessons', $one[0]['value'] );
eq( 'direct type legacy icon', 'tutor-icon-meeting', $one[0]['icon_class'] );
eq( 'direct type learning area icon', 'video-camera', $frontend->learning_area_rows( array(), 303 )[0]['icon'] );
eq( 'direct study value', '1v1 study', $one[1]['value'] );
eq( 'direct study icon', 'tutor-icon-user-line', $one[1]['icon_class'] );
eq( 'direct study icon (learning area)', 'user', $frontend->learning_area_rows( array(), 303 )[1]['icon'] );
eq( 'direct number value', '3 live sessions for 2 hours per session', $one[2]['value'] );

echo "\n=== Front end rows (prerecorded course 999) ===\n";

$pre = $frontend->legacy_sidebar_rows( array(), 999 );
eq( 'prerecorded shows exactly one row', 1, count( $pre ) );
eq( 'prerecorded label', 'Course Type', $pre[0]['label'] );
eq( 'prerecorded value', 'Prerecorded lessons', $pre[0]['value'] );
eq( 'prerecorded legacy icon', 'tutor-icon-video-camera', $pre[0]['icon_class'] );
eq( 'prerecorded learning area icon', 'monitor-play', $frontend->learning_area_rows( array(), 999 )[0]['icon'] );
eq( 'prerecorded learning area content', 'Prerecorded lessons', $frontend->learning_area_rows( array(), 999 )[0]['content'] );

echo "\n=== Number row degrades when only half is filled ===\n";

$GLOBALS['tcf_meta'][777] = array(
	TCF_META_TYPE     => 'direct',
	TCF_META_FORMAT   => 'group',
	TCF_META_SESSIONS => 5,
	TCF_META_LENGTH   => '',
);
eq( 'sessions only', '5 live sessions', $frontend->legacy_sidebar_rows( array(), 777 )[2]['value'] );

$GLOBALS['tcf_meta'][888] = array(
	TCF_META_TYPE     => 'direct',
	TCF_META_FORMAT   => 'group',
	TCF_META_SESSIONS => '',
	TCF_META_LENGTH   => 1,
);
eq( 'length only, exactly one hour', '1 hour per session', $frontend->legacy_sidebar_rows( array(), 888 )[2]['value'] );

$GLOBALS['tcf_meta'][889] = array(
	TCF_META_TYPE     => 'direct',
	TCF_META_FORMAT   => 'group',
	TCF_META_SESSIONS => 2,
	TCF_META_LENGTH   => 1,
);
eq( 'singular live session + singular hour', '2 live sessions for 1 hour per session', $frontend->legacy_sidebar_rows( array(), 889 )[2]['value'] );

$GLOBALS['tcf_meta'][991] = array(
	TCF_META_TYPE     => 'direct',
	TCF_META_FORMAT   => 'group',
	TCF_META_SESSIONS => 1,
	TCF_META_LENGTH   => 2.5,
);
eq( 'singular live session', '1 live session for 2.5 hours per session', $frontend->legacy_sidebar_rows( array(), 991 )[2]['value'] );

$GLOBALS['tcf_meta'][990] = array(
	TCF_META_TYPE     => 'direct',
	TCF_META_FORMAT   => 'group',
	TCF_META_SESSIONS => '',
	TCF_META_LENGTH   => '',
);
eq( 'neither filled: number row omitted', 2, count( $frontend->legacy_sidebar_rows( array(), 990 ) ) );

echo "\n=== Course type wording can be filtered ===\n";

function tcf_test_type_label( $label, $type ) { return 'hybrid' === $type ? 'Both kinds' : $label; }
add_filter( 'tcf_display_type_label', 'tcf_test_type_label', 10, 2 );
eq( 'filtered type label', 'Both kinds', $frontend->legacy_sidebar_rows( array(), 202 )[0]['value'] );
$GLOBALS['tcf_filters']['tcf_display_type_label'] = array();

echo "\n=== Front end appends, does not replace ===\n";

$existing = array( array( 'icon_class' => 'tutor-icon-level', 'label' => 'Level', 'value' => 'Beginner' ) );
$merged   = $frontend->legacy_sidebar_rows( $existing, 202 );
eq( 'existing rows preserved', 4, count( $merged ) );
eq( 'existing row still first', 'Level', $merged[0]['label'] );

echo "\n=== Front end display can be filtered off ===\n";

add_filter( 'tcf_display_on_course_page', '__return_false_stub' );
function __return_false_stub() { return false; }
eq( 'rows suppressed by filter', 0, count( $frontend->legacy_sidebar_rows( array(), 202 ) ) );
$GLOBALS['tcf_filters']['tcf_display_on_course_page'] = array();

/* --------------------------------------------------------------------- *
 * Admin metabox
 * --------------------------------------------------------------------- */

echo "\n=== wp-admin metabox ===\n";

$metabox = new TCF_Admin_Metabox();
$metabox->add_metabox();
t( 'metabox registered', isset( $GLOBALS['tcf_metaboxes']['tcf-course-format'] ) );
eq( 'metabox on courses screen', 'courses', $GLOBALS['tcf_metaboxes']['tcf-course-format']['screen'] );
eq( 'metabox in the side context', 'side', $GLOBALS['tcf_metaboxes']['tcf-course-format']['context'] );

tcf_save_course_format( 707, array(
	TCF_FIELD_TYPE     => 'direct',
	TCF_FIELD_FORMAT   => 'one_to_one',
	TCF_FIELD_SESSIONS => '8',
	TCF_FIELD_LENGTH   => '2.5',
) );

ob_start();
$metabox->render( new WP_Post( 707 ) );
$html = ob_get_clean();

t( 'nonce rendered', false !== strpos( $html, 'name="tcf_metabox_nonce"' ) );
t( 'type select rendered', false !== strpos( $html, 'name="' . TCF_FIELD_TYPE . '"' ) );
t( 'format select rendered', false !== strpos( $html, 'name="' . TCF_FIELD_FORMAT . '"' ) );
t( 'sessions input rendered', false !== strpos( $html, 'name="' . TCF_FIELD_SESSIONS . '"' ) );
t( 'length input rendered', false !== strpos( $html, 'name="' . TCF_FIELD_LENGTH . '"' ) );
t( 'stored type selected', (bool) preg_match( '/value="direct"\s+selected=/', $html ) );
t( 'stored format selected', (bool) preg_match( '/value="one_to_one"\s+selected=/', $html ) );
t( 'stored sessions prefilled', false !== strpos( $html, 'value="8"' ) );
t( 'stored length prefilled', false !== strpos( $html, 'value="2.5"' ) );
t( 'live block visible for direct course', false === strpos( $html, 'class="tcf-live-only" hidden' ) );

ob_start();
$metabox->render( new WP_Post( 999 ) );
$htmlPre = ob_get_clean();
t( 'live block hidden for prerecorded course', false !== strpos( $htmlPre, 'class="tcf-live-only" hidden' ) );

$metabox->enqueue( 'post.php' );
t( 'admin css enqueued on post.php', isset( $GLOBALS['tcf_styles']['tcf-admin'] ) );
t( 'admin js enqueued on post.php', isset( $GLOBALS['tcf_scripts']['tcf-admin-metabox'] ) );

$GLOBALS['tcf_styles'] = array();
unset( $GLOBALS['tcf_scripts']['tcf-admin-metabox'] );
$metabox->enqueue( 'edit.php' );
t( 'nothing enqueued on an unrelated screen', ! isset( $GLOBALS['tcf_styles']['tcf-admin'] ) && ! isset( $GLOBALS['tcf_scripts']['tcf-admin-metabox'] ) );

/* --------------------------------------------------------------------- *
 * Summary
 * --------------------------------------------------------------------- */

echo "\n==========================================\n";
echo "  {$GLOBALS['tcf_pass']} passed, {$GLOBALS['tcf_fail']} failed\n";
echo "==========================================\n\n";

exit( $GLOBALS['tcf_fail'] > 0 ? 1 : 0 );
