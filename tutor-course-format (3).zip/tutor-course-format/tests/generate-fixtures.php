<?php
/**
 * Regenerate the fixtures consumed by tests/js-tests.js.
 *
 * The fixtures are produced by the real PHP classes so the browser tests
 * exercise the same payload and markup WordPress would emit.
 *
 * Run: php tests/generate-fixtures.php
 *
 * @package TutorCourseFormat
 */

// The harness defines the WordPress + Tutor shim and loads the plugin.
$tests = __DIR__ . '/run-tests.php';
if ( ! file_exists( $tests ) ) {
	fwrite( STDERR, "tests/run-tests.php not found\n" );
	exit( 1 );
}

ob_start();
require $tests;
ob_end_clean();

$metabox = new TCF_Admin_Metabox();
$builder = new TCF_Course_Builder();

file_put_contents(
	__DIR__ . '/fixture-builder-config.json',
	wp_json_encode( $builder->get_js_config() )
);

tcf_save_course_format(
	808,
	array(
		TCF_FIELD_TYPE     => 'direct',
		TCF_FIELD_FORMAT   => 'one_to_one',
		TCF_FIELD_SESSIONS => '6',
		TCF_FIELD_LENGTH   => '1.5',
	)
);

ob_start();
$metabox->render( new WP_Post( 808 ) );
file_put_contents( __DIR__ . '/fixture-metabox-live.html', ob_get_clean() );

ob_start();
$metabox->render( new WP_Post( 999 ) );
file_put_contents( __DIR__ . '/fixture-metabox-prerecorded.html', ob_get_clean() );

echo "Fixtures written to tests/\n";
