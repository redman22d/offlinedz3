/*
 * Browser probe: log into the test site, open the Tutor LMS course builder,
 * and report whether our custom fields register, render, and reach the
 * save request. Read-only diagnostics + one save attempt.
 */
'use strict';

const puppeteer = require('/tmp/browsertest/node_modules/puppeteer-core');

const BASE = 'http://localhost:8899';
const COURSE_ID = process.argv[2] || '8';
const USER = process.env.TCF_USER || 'admin';
const PASS = process.env.TCF_PASS || 'admin';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium',
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1600, height: 1200 });

  const logs = [];
  page.on('console', (m) => logs.push(`[${m.type()}] ${m.text()}`));
  page.on('pageerror', (e) => logs.push(`[pageerror] ${e.message}`));
  page.on('requestfailed', (r) => logs.push(`[reqfail] ${r.url()} ${r.failure() && r.failure().errorText}`));

  // Capture every admin-ajax / REST payload the builder sends on save.
  const saves = [];
  page.on('request', (req) => {
    const u = req.url();
    if (u.includes('admin-ajax.php') || u.includes('/wp/v2/')) {
      let body = req.postData() || '';
      if (/tutor_(update|create)_course/.test(body) || /tutor_(update|create)_course/.test(u)) {
        saves.push({ url: u, body });
      }
    }
  });

  // ---- log in -------------------------------------------------------
  await page.goto(`${BASE}/wp-login.php`, { waitUntil: 'networkidle2' });
  await page.type('#user_login', USER);
  await page.type('#user_pass', PASS);
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle2' }),
    page.click('#wp-submit'),
  ]);

  // ---- open the course builder -------------------------------------
  await page.goto(`${BASE}/wp-admin/admin.php?page=create-course&course_id=${COURSE_ID}`, {
    waitUntil: 'networkidle2',
    timeout: 90000,
  });

  await new Promise((r) => setTimeout(r, 12000));

  const report = await page.evaluate(() => {
    const out = {};
    out.hasWindowTutor = !!(window.Tutor && window.Tutor.CourseBuilder);
    out.hasConfig = !!window.tcfCourseFormat;
    out.scriptTagPresent = !!document.querySelector('script[src*="tcf-course-builder"]');

    const inputs = Array.from(document.querySelectorAll('input,select,textarea'))
      .map((el) => el.name)
      .filter(Boolean);
    out.allFieldNames = Array.from(new Set(inputs));
    out.tcfFieldsInDom = inputs.filter((n) => n.indexOf('tcf_') === 0);

    out.radioChecked = {};
    document.querySelectorAll('input[name^="tcf_"][type="radio"]:checked').forEach((el) => {
      out.radioChecked[el.name] = el.value;
    });
    out.numberValues = {};
    document.querySelectorAll('input[name^="tcf_"][type="number"]').forEach((el) => {
      out.numberValues[el.name] = el.value;
    });

    // Find the save buttons on screen.
    out.buttons = Array.from(document.querySelectorAll('button'))
      .map((b) => (b.textContent || '').trim())
      .filter((t) => t && t.length < 40)
      .slice(0, 40);

    return out;
  });

  console.log('=== PAGE REPORT ===');
  console.log(JSON.stringify(report, null, 2));

  // ---- try to interact + save ---------------------------------------
  if (report.tcfFieldsInDom.length) {
    await page.evaluate(() => {
      const setVal = (name, value) => {
        const el = document.querySelector(`input[name="${name}"]`);
        if (!el) return false;
        const setter = Object.getOwnPropertyDescriptor(
          window.HTMLInputElement.prototype, 'value').set;
        setter.call(el, value);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      };
      const radio = document.querySelector('input[name="tcf_course_type"][value="direct"]');
      if (radio) {
        radio.click();
        radio.dispatchEvent(new Event('change', { bubbles: true }));
      }
      setVal('tcf_session_count', '12');
      setVal('tcf_session_length', '2.5');
    });
    await new Promise((r) => setTimeout(r, 1500));

    const clicked = await page.evaluate(() => {
      const btn = Array.from(document.querySelectorAll('button')).find((b) => {
        const t = (b.textContent || '').trim().toLowerCase();
        return ['update','save','save course','update course','publish','submit'].indexOf(t) !== -1;
      });
      if (btn) { btn.click(); return (btn.textContent || '').trim(); }
      return null;
    });
    console.log('clicked save button:', clicked);
    await new Promise((r) => setTimeout(r, 6000));
  }

  console.log('=== SAVE REQUESTS CAPTURED:', saves.length, '===');
  saves.forEach((s, i) => {
    // Body is multipart/form-data - parse the part names and values directly.
    const parts = [];
    const re = /name="([^"]*)"(?:\r\n\r\n|\r\n)?([\s\S]*?)(?=\r\n--|$)/g;
    let m;
    while ((m = re.exec(s.body)) !== null) parts.push([m[1], m[2].trim()]);
    const tcf = {};
    parts.forEach(([k, v]) => { if (k.indexOf('tcf_') === 0) tcf[k] = v; });
    console.log(`#${i} ${s.url}`);
    console.log('   tcf keys in payload:', JSON.stringify(tcf));
    console.log('   all keys:', parts.map((p2) => p2[0]).join(', '));
  });

  console.log('=== CONSOLE (last 25) ===');
  console.log(logs.slice(-25).join('\n'));

  await browser.close();
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
