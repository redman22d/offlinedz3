<?php
/**
 * Plugin Name:       Tutor LMS Course Format
 * Plugin URI:        https://example.com/tutor-course-format
 * Description:       Adds Course Type (Prerecorded / Direct / Hybrid), delivery format (Group / 1v1), sessions number and session length fields to the Tutor LMS course editor, and shows them on the course page.
 * Version:           1.2.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Your Name
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tutor-course-format
 * Domain Path:       /languages
 *
 * Tested with Tutor LMS 4.0.7 (free). Works with Tutor LMS Pro 3.x/4.x as well.
 *
 * @package TutorCourseFormat
 */

defined( 'ABSPATH' ) || exit;

define( 'TCF_VERSION', '1.2.0' );
define( 'TCF_FILE', __FILE__ );
define( 'TCF_DIR', plugin_dir_path( __FILE__ ) );
define( 'TCF_URL', plugin_dir_url( __FILE__ ) );

/**
 * Meta keys.
 */
define( 'TCF_META_TYPE', '_tcf_course_type' );
define( 'TCF_META_FORMAT', '_tcf_course_format' );
define( 'TCF_META_SESSIONS', '_tcf_session_count' );
define( 'TCF_META_LENGTH', '_tcf_session_length' );

/**
 * Payload / REST / form field names.
 *
 * These are the exact keys used by the Tutor LMS course builder for both
 * saving (POST) and loading (tutor_course_details_response).
 */
define( 'TCF_FIELD_TYPE', 'tcf_course_type' );
define( 'TCF_FIELD_FORMAT', 'tcf_course_format' );
define( 'TCF_FIELD_SESSIONS', 'tcf_session_count' );
define( 'TCF_FIELD_LENGTH', 'tcf_session_length' );

require_once TCF_DIR . 'includes/tcf-helpers.php';
require_once TCF_DIR . 'includes/class-tcf-plugin.php';
require_once TCF_DIR . 'includes/class-tcf-course-builder.php';
require_once TCF_DIR . 'includes/class-tcf-admin-metabox.php';
require_once TCF_DIR . 'includes/class-tcf-frontend.php';

/**
 * Boot.
 *
 * @return void
 */
function tcf_boot() {
	if ( ! tcf_is_tutor_active() ) {
		add_action( 'admin_notices', 'tcf_missing_tutor_notice' );
		return;
	}

	TCF_Plugin::instance()->init();
}
add_action( 'plugins_loaded', 'tcf_boot', 20 );

/**
 * Admin notice when Tutor LMS is missing.
 *
 * @return void
 */
function tcf_missing_tutor_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'Tutor LMS Course Format requires the Tutor LMS plugin to be installed and active.', 'tutor-course-format' )
	);
}

/**
 * Activation / deactivation.
 */
register_activation_hook( __FILE__, 'tcf_activate' );

/**
 * On activation make sure the default exists for already published courses.
 *
 * We intentionally do NOT bulk-write meta: a missing `_tcf_course_type`
 * already resolves to "prerecorded" via tcf_get_course_type().
 *
 * @return void
 */
function tcf_activate() {
	flush_rewrite_rules();
}
